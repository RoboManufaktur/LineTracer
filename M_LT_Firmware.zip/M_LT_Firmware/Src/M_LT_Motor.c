/*
 * M_LT_Motor.c
 *
 *  Created on: Mar 18, 2024
 *      Author: ismarintan
 */


#include "M_LT_Motor.h"
#include "tim.h"
#include "stdlib.h"


short int ENC_Speed[2];
int32_t ENC_Count[2];
int16_t PWM_Motor[2];

float Motor_Kp[2]={0.03,0.03};
float Motor_Ki[2]={0.06,0.06};

int Motor_SpeedSP[2];

int16_t PWM_Test[2];


float distL, distR;




void Motor_Init(void)
{

	// Start PWM
	HAL_TIM_PWM_Start(&htim13, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim14, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);

	//Start Encoder
	HAL_TIM_Encoder_Start(&htim1, TIM_CHANNEL_ALL);
	HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);

	//  Enable Motor
	Motor_EN(1);
}


void MotorPWM(int16_t PWM1,int16_t PWM2)
{

	if(PWM1 > 0)
	{
		TIM14->CCR1 = PWM1;
		TIM13->CCR1 = 0;
	}
	else
	{
		TIM14->CCR1 = 0;
		TIM13->CCR1 = PWM1 * -1;
	}

	if(PWM2 > 0)
	{
		TIM3->CCR3 = PWM2;
		TIM3->CCR4 = 0;
	}
	else
	{
		TIM3->CCR3 = 0;
		TIM3->CCR4 = PWM2 * -1;
	}


}


void MotorSetSpeed(int speedL,int speedR)
{

	float M_Error[2];
	static float M_SumError[2];
	float P[2],I[2];

	float M_Out[2];

	float SP_Speed[2];
	SP_Speed[0] = speedL * 10;
	SP_Speed[1] = speedR * 10;

	for(int i=0;i<2;i++)
	{
		M_Error[i] = SP_Speed[i] - ENC_Speed[i];

		M_SumError[i] += M_Error[i];

		if(M_SumError[i] > 499)
			M_SumError[i] = 499;
		else if(M_SumError[i] < -499)
			M_SumError[i] = -499;

		if(SP_Speed[i] == 0)
			M_SumError[i] = 0;

		P[i] = Motor_Kp[i] * M_Error[i];
		I[i] = Motor_Ki[i] * M_SumError[i];

		M_Out[i] = P[i] + I[i];

		if(M_Out[i] > 499)
			M_Out[i] = 499;
		else if(M_Out[i] < -499)
			M_Out[i] = -499;
	}

	MotorPWM((int16_t)M_Out[0],(int16_t)M_Out[1]);

}


void MotorRoutine(void)
{
	ENC_Speed[0] = -TIM4->CNT;
	ENC_Speed[1] = TIM1->CNT;

	TIM1->CNT = TIM4->CNT = 0;

	ENC_Count[0] += ENC_Speed[0];
	ENC_Count[1] += ENC_Speed[1];

	distL += (float)ENC_Speed[0] * 0.001;
	distR += (float)ENC_Speed[1] * 0.001;

	MotorSetSpeed(Motor_SpeedSP[0], Motor_SpeedSP[1]);

//	MotorPWM(PWM_Test[0], PWM_Test[1]);


}


