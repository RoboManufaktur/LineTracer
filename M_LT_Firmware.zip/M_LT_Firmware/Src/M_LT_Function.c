/*
 * M_LT_Function.c
 *
 *  Created on: Mar 18, 2024
 *      Author: ismarintan
 */

#include <M_LT_Function.h>
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "fatfs.h"
#include "i2c.h"
#include "sdio.h"
#include "tim.h"
#include "gpio.h"
#include "File_Handling.h"
#include "ssd1306.h"
#include "fonts.h"
#include "stdbool.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "M_LT_Motor.h"
#include "math.h"

HAL_SD_CardInfoTypeDef CardInfo;
M_LT_Button_Structure LT_Button;

uint32_t ADC_Buffer[3];
uint16_t ADC_Value[6];

uint16_t Line_ADC[16];
uint16_t Line_ADC_Buf[16];
uint8_t  Line_IdxRead;

float Line_Constant[16] = {-1660,-800,-400,-155,-110,-90,-35,-10.5,
							10.5,35,90,110,155,400,800,1660
};

float Line_Eror;


int SpeedJalan = 50;


int Line_Bit[16];
uint16_t Line_Max[16];
uint16_t Line_Min[16];
uint16_t Line_Threshold[16];

uint32_t time_prev,time_s;

int MotorSpeed_SP[2];

// PID Line
float Proportional,Derivative,Integral;
float Kp = 100, Ki = 0, Kd = 10;
float prev_error,sum_error;

uint32_t TimeButton;
M_LT_Menu LT_Menu;
M_LT_Menu SUB_MENU[3] = {CALIB,SPEED,PID};

extern uint8_t SSD1306_Buffer[SSD1306_WIDTH * SSD1306_HEIGHT / 8];
int sensMap[16];

uint8_t sens_view;


// Load And Save Param
char buff_save[64];

uint8_t test_save,test_read;

uint8_t any_config;

extern FATFS fs;  // file system
extern FIL fil; // File
extern FILINFO fno;
extern FRESULT fresult;  // result
extern UINT br, bw;  // File read/write count

uint32_t time_button;

uint8_t Sub_Setting;
uint8_t Sub_y[3] = {20,32,44};


float V_BAT;

uint16_t idx_mission;
uint32_t time_mission;
float prev_gyro;
extern float yaw,yaw_deg;



long map(long x, long in_min, long in_max, long out_min, long out_max) {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}


void M_LT_System_Init(void)
{

	//Enable Timer PWM LED
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);

	//Enable Timer PWM Buzzer
	HAL_TIM_PWM_Start(&htim12, TIM_CHANNEL_1);

	// LCD Setup
	ssd1306_Init(&hi2c1);
	ssd1306_SetCursor(15, 36);
	ssd1306_WriteString("M Line Tracer",Font_7x10, White);
	ssd1306_UpdateScreen(&hi2c1);
	//Blink LED Sensor & Buzzer
	for(int i=0;i<4;i++)
	{
		LED_PWM(400);
		BUZZ_PWM(250);
		HAL_Delay(100);

		LED_PWM(0);
		BUZZ_PWM(0);
		HAL_Delay(100);
	}

	// Switch POWER ON
	PB_ON(1);

	// Enable Motor
	Motor_Init();

	// File System SD Card
	HAL_SD_Init(&hsd);
	HAL_SD_GetCardInfo(&hsd, &CardInfo);
	HAL_Delay(100);
	Mount_SD("/");
	Load_Param();



	//Start ADC DMA
	HAL_ADC_Start_DMA(&hadc1, ADC_Buffer, 6);

	//Start Timer Interrupt TIM6 1Khz
	HAL_TIM_Base_Start_IT(&htim6);

	//Start Timer Interrupt TIM7 50Hz
	HAL_TIM_Base_Start_IT(&htim7);

	// ------------ LED ON
	LED_PWM(400);

	// LCD Clear
	ssd1306_Fill(Black);
	ssd1306_UpdateScreen(&hi2c1);
	HAL_Delay(100);


	//Disable Motor
	Motor_EN(0);



}


void M_LT_ButtonRead(void)
{


	LT_Button.BT_L_UP = HAL_GPIO_ReadPin(SW6_GPIO_Port, SW6_Pin);
	LT_Button.BT_L_DOWN = HAL_GPIO_ReadPin(SW5_GPIO_Port, SW5_Pin);
	LT_Button.BT_L_OK = HAL_GPIO_ReadPin(SW7_GPIO_Port, SW7_Pin);

	LT_Button.BT_R_UP = HAL_GPIO_ReadPin(SW3_GPIO_Port, SW3_Pin);
	LT_Button.BT_R_DOWN = HAL_GPIO_ReadPin(SW1_GPIO_Port, SW1_Pin);
	LT_Button.BT_R_OK = HAL_GPIO_ReadPin(SW2_GPIO_Port, SW2_Pin);

	LT_Button.BT_POWER = HAL_GPIO_ReadPin(PB_Power_GPIO_Port, PB_Power_Pin);



	// Press Hold OK L and OK R to power off
	if(LT_Button.BT_POWER)
	{
		if(HAL_GetTick()-TimeButton > 2000)
		{
			LT_Menu = POWER_OFF;
		}
	}
	else
	{
		TimeButton = HAL_GetTick();
	}




}

void ADC_Parse(void)
{
	ADC_Value[0] = ADC_Buffer[0] & 0xFFFF;
	ADC_Value[1] = (ADC_Buffer[0] >> 16) & 0xFFFF;
	ADC_Value[2] = ADC_Buffer[1] & 0xFFFF;
	ADC_Value[3] = (ADC_Buffer[1] >> 16) & 0xFFFF;
	ADC_Value[4] = ADC_Buffer[2] & 0xFFFF;
	ADC_Value[5] = (ADC_Buffer[2] >> 16) & 0xFFFF;
}

void LineSensor_Read(void)
{

	Line_ADC_Buf[Line_IdxRead] = ADC_Value[1];

	HAL_GPIO_WritePin(MUX_S0_GPIO_Port, MUX_S0_Pin, Line_IdxRead & 0x01);
	HAL_GPIO_WritePin(MUX_S1_GPIO_Port, MUX_S1_Pin, (Line_IdxRead >> 1) & 0x01);
	HAL_GPIO_WritePin(MUX_S2_GPIO_Port, MUX_S2_Pin, (Line_IdxRead >> 2) & 0x01);
	HAL_GPIO_WritePin(MUX_S3_GPIO_Port, MUX_S3_Pin, (Line_IdxRead >> 3) & 0x01);

	if(++Line_IdxRead > 15)
	{

		for(int i=0;i<15;i++)
		{
			Line_ADC[i] = Line_ADC_Buf[i+1];
		}

		Line_ADC[15] = Line_ADC_Buf[0];


		Line_IdxRead = 0;
	}

	for(int i=0;i<16;i++)
	{
		if(Line_ADC[i] < Line_Threshold[i])
			Line_Bit[i] = true;
		else
			Line_Bit[i] = false;
	}


	time_s = HAL_GetTick() - time_prev;
	time_prev = HAL_GetTick();

}


void LineSensor_Calibration(void)
{
	for(int i=0;i<16;i++)
	{
		if(Line_ADC[i] < Line_Min[i])
			Line_Min[i] = Line_ADC[i];

		if(Line_ADC[i] > Line_Max[i])
			Line_Max[i] = Line_ADC[i];

	}
}

void LCD_Menu(M_LT_Menu menu)
{
	char buff_lcd[20];
	if(HAL_GetTick()>4000)
		V_BAT = (ADC_Value[0] * 0.005262712)*0.01 + V_BAT*0.99;
	else
		V_BAT = (ADC_Value[0] * 0.005262712);


	switch(menu)
	{
	case HOME :

		ssd1306_SetCursor(1, 1);
		ssd1306_WriteString("------ HOME ------", Font_7x10, White);

		sprintf(buff_lcd,"%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",Line_Bit[15],
				Line_Bit[14],Line_Bit[13],Line_Bit[12],Line_Bit[11],Line_Bit[10],
				Line_Bit[9],Line_Bit[8],Line_Bit[7],Line_Bit[6],Line_Bit[5],
				Line_Bit[4],Line_Bit[3],Line_Bit[2],Line_Bit[1],Line_Bit[0]);
		ssd1306_SetCursor(9, 20);
		ssd1306_WriteString(buff_lcd, Font_7x10, White);



		sprintf(buff_lcd,"<SET         RUN>");
		ssd1306_SetCursor(10, 36);
		ssd1306_WriteString(buff_lcd, Font_7x10, White);

		int v_a,v_b;
		v_a = (int)V_BAT;
		v_b = (int)((V_BAT - v_a) * 100);


		if(sens_view == 0)
		{
			sprintf(buff_lcd,"V:%d.%d",v_a,v_b);
			ssd1306_SetCursor(45, 45);
			ssd1306_WriteString(buff_lcd, Font_7x10, White);
		}
		else if(sens_view == 1)
		{
			sprintf(buff_lcd,"dL:%.2f",distL);
			ssd1306_SetCursor(45, 45);
			ssd1306_WriteString(buff_lcd, Font_7x10, White);
		}
		else if(sens_view == 2)
		{
			sprintf(buff_lcd,"dR:%.2f",distR);
			ssd1306_SetCursor(45, 45);
			ssd1306_WriteString(buff_lcd, Font_7x10, White);

		}
		else if(sens_view == 3)
		{
			sprintf(buff_lcd,"g:%.2f",yaw_deg);
			ssd1306_SetCursor(45, 45);
			ssd1306_WriteString(buff_lcd, Font_7x10, White);
		}



		ssd1306_UpdateScreen(&hi2c1);


		if(!LT_Button.BT_L_OK_PREV && LT_Button.BT_L_OK)
		{
			LT_Menu = SETTING;
			ssd1306_Fill(Black);
		}


		if(!LT_Button.BT_R_OK_PREV && LT_Button.BT_R_OK)
		{
			LT_Menu = RUNING;
			ssd1306_Fill(Black);
		}


		if(!LT_Button.BT_R_UP_PREV && LT_Button.BT_R_UP)
		{
			if(++sens_view > 3)
				sens_view = 0;
			ssd1306_Fill(Black);
		}

		if(!LT_Button.BT_R_DOWN_PREV && LT_Button.BT_R_DOWN)
		{
			if(--sens_view > 5)
				sens_view = 3;
			ssd1306_Fill(Black);
		}

		Sub_Setting = 0;



		break;

	case SETTING:


		ssd1306_SetCursor(1, 1);
		ssd1306_WriteString("---- SETTING ----", Font_7x10, White);

		ssd1306_SetCursor(28, 20);
		ssd1306_WriteString("Calibration",Font_7x10, White);

		ssd1306_SetCursor(28, 32);
		ssd1306_WriteString("Speed",Font_7x10, White);

		ssd1306_SetCursor(28, 44);
		ssd1306_WriteString("PID",Font_7x10, White);

		ssd1306_SetCursor(8, Sub_y[Sub_Setting]);
		ssd1306_WriteString("->", Font_7x10, White);

		ssd1306_UpdateScreen(&hi2c1);

		if(!LT_Button.BT_L_DOWN_PREV && LT_Button.BT_L_DOWN)
		{
			if(++Sub_Setting>2)
				Sub_Setting = 0;

			ssd1306_Fill(Black);
		}

		if(!LT_Button.BT_L_UP_PREV && LT_Button.BT_L_UP)
		{
			if(--Sub_Setting>10)
				Sub_Setting = 2;

			ssd1306_Fill(Black);
		}


		if(!LT_Button.BT_R_OK_PREV && LT_Button.BT_R_OK)
		{
			LT_Menu = HOME;
			ssd1306_Fill(Black);
		}


		if(!LT_Button.BT_L_OK_PREV && LT_Button.BT_L_OK)
		{
			LT_Menu = SUB_MENU[Sub_Setting];
			ssd1306_Fill(Black);

			if(LT_Menu == CALIB)
			{
				memset(Line_Min,4095,sizeof(Line_Min));
				memset(Line_Max,0,sizeof(Line_Max));
			}
			else if(LT_Menu == PID)
			{

			}

			Sub_Setting = 0;

		}

		break;

	case CALIB:

		ssd1306_SetCursor(1, 1);
		ssd1306_WriteString("----CALIBRATION----", Font_7x10, White);

		ssd1306_SetCursor(1, 25);
		ssd1306_WriteString("Sensor Calibrating ...", Font_7x10, White);

		ssd1306_SetCursor(1, 44);
		ssd1306_WriteString("<CANCEL     SAVE>", Font_7x10, White);


		ssd1306_UpdateScreen(&hi2c1);

		LineSensor_Calibration();

		// Save
		if(!LT_Button.BT_R_OK_PREV && LT_Button.BT_R_OK)
		{

			for (int i=0;i<16;i++)
				Line_Threshold[i] = ((Line_Max[i] - Line_Min[i]) / 2)-50;

			LT_Menu = SETTING;
			ssd1306_Fill(Black);
			ssd1306_SetCursor(1, 25);
			ssd1306_WriteString("Saving ....", Font_7x10, White);
			ssd1306_UpdateScreen(&hi2c1);
			HAL_Delay(2000);
			ssd1306_Fill(Black);
			Save_Param();
		}

		// CANCEL
		if(!LT_Button.BT_L_OK_PREV && LT_Button.BT_L_OK)
		{
			LT_Menu = SETTING;
			ssd1306_Fill(Black);
			ssd1306_SetCursor(1, 25);
			ssd1306_WriteString("CANCEL ....", Font_7x10, White);
			ssd1306_UpdateScreen(&hi2c1);
			HAL_Delay(1200);
			ssd1306_Fill(Black);
		}

		break;


	case SPEED:

		ssd1306_SetCursor(1, 1);
		ssd1306_WriteString("----SET SPEED----", Font_7x10, White);

		ssd1306_SetCursor(1, 22);
		sprintf(buff_lcd,"%5d",SpeedJalan);
		ssd1306_WriteString(buff_lcd, Font_7x10, White);

		if(/*!LT_Button.BT_R_OK_PREV && */!LT_Button.BT_R_OK)
		{
			LT_Menu = SETTING;
			ssd1306_Fill(Black);
			ssd1306_SetCursor(1, 25);
			ssd1306_WriteString("Saving ....", Font_7x10, White);
			ssd1306_UpdateScreen(&hi2c1);
			HAL_Delay(2000);
			ssd1306_Fill(Black);
			Save_Param();
		}

		if(!LT_Button.BT_R_UP)
		{
			if(++SpeedJalan>1000)
				SpeedJalan = 1000;
		}

		if(!LT_Button.BT_R_DOWN)
		{
			if(--SpeedJalan<0)
				SpeedJalan = 0;
		}

		ssd1306_UpdateScreen(&hi2c1);


		break;


	case PID:
		ssd1306_SetCursor(1, 1);
		ssd1306_WriteString("----SET PID----", Font_7x10, White);

		int kp_v,ki_v,kd_v;

		kp_v = Kp;
		ki_v = Ki;
		kd_v = Kd;

		ssd1306_SetCursor(28, 20);
		sprintf(buff_lcd,"Kp:%4d",kp_v);
		ssd1306_WriteString(buff_lcd, Font_7x10, White);

		ssd1306_SetCursor(28, 32);
		sprintf(buff_lcd,"Ki:%4d",ki_v);
		ssd1306_WriteString(buff_lcd, Font_7x10, White);

		ssd1306_SetCursor(28, 44);
		sprintf(buff_lcd,"Kd:%4d",kd_v);
		ssd1306_WriteString(buff_lcd, Font_7x10, White);


		ssd1306_SetCursor(8, Sub_y[Sub_Setting]);
		ssd1306_WriteString("->", Font_7x10, White);

		ssd1306_UpdateScreen(&hi2c1);

		if(!LT_Button.BT_R_OK_PREV && LT_Button.BT_R_OK)
		{
			LT_Menu = SETTING;
			ssd1306_Fill(Black);
			HAL_Delay(100);
			ssd1306_SetCursor(1, 25);
			ssd1306_WriteString("Saving ....", Font_7x10, White);
			ssd1306_UpdateScreen(&hi2c1);
			HAL_Delay(2000);
			ssd1306_Fill(Black);
			Save_Param();
		}
		else if(!LT_Button.BT_L_DOWN_PREV && LT_Button.BT_L_DOWN)
		{
			if(++Sub_Setting>2)
				Sub_Setting = 0;

			ssd1306_Fill(Black);
		}
		else if(!LT_Button.BT_L_UP_PREV && LT_Button.BT_L_UP)
		{
			if(--Sub_Setting>10)
				Sub_Setting = 2;

			ssd1306_Fill(Black);
		}
		else if(!LT_Button.BT_R_UP_PREV && LT_Button.BT_R_UP)
		{
			if(Sub_Setting==0)
			{
				if(++Kp > 1000)
					Kp = 1000;
			}
			else if(Sub_Setting==1)
			{
				if(++Ki > 1000)
					Ki = 1000;
			}
			else if(Sub_Setting==2)
			{
				if(++Kd > 1000)
					Kd = 1000;
			}
		}
		else if(!LT_Button.BT_R_DOWN_PREV && LT_Button.BT_R_DOWN)
		{
			if(Sub_Setting==0)
			{
				if(--Kp <0)
					Kp = 0;
			}
			else if(Sub_Setting==1)
			{
				if(--Ki < 0)
					Ki = 0;
			}
			else if(Sub_Setting==2)
			{
				if(--Kd < 0)
					Kd = 0;
			}
		}




		break;


	case RUNING:
		ssd1306_SetCursor(1, 1);
		ssd1306_WriteString("-----RUNNING-----", Font_7x10, White);


		sprintf(buff_lcd,"%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",Line_Bit[15],
				Line_Bit[14],Line_Bit[13],Line_Bit[12],Line_Bit[11],Line_Bit[10],
				Line_Bit[9],Line_Bit[8],Line_Bit[7],Line_Bit[6],Line_Bit[5],
				Line_Bit[4],Line_Bit[3],Line_Bit[2],Line_Bit[1],Line_Bit[0]);
		ssd1306_SetCursor(9, 20);
		ssd1306_WriteString(buff_lcd, Font_7x10, White);

		sprintf(buff_lcd,"Mission:%3d",idx_mission);
		ssd1306_SetCursor(9, 42);
		ssd1306_WriteString(buff_lcd, Font_7x10, White);

		ssd1306_UpdateScreen(&hi2c1);

		if(!LT_Button.BT_L_OK_PREV && LT_Button.BT_L_OK)
		{
			LT_Menu = HOME;
			ssd1306_Fill(Black);
			idx_mission = 0;
		}


		break;


	case POWER_OFF:

		ssd1306_Fill(Black);
		ssd1306_UpdateScreen(&hi2c1);

		LT_Menu = OFF;

		break;

	case OFF:

		ssd1306_SetCursor(1, 1);
		ssd1306_WriteString(" POWER OFF ", Font_11x18, White);
		ssd1306_UpdateScreen(&hi2c1);
		HAL_Delay(500);

		for(int i=0;i<2;i++)
		{
			BUZZ_PWM(400);
			HAL_Delay(200);
			BUZZ_PWM(0);
			HAL_Delay(100);
		}

		PB_ON(0);
		LT_Menu = -1;

		break;
	}



}



void M_LT_ControlRoutine(void)
{

//	M_LT_LineRun(SpeedJalan,0);
/*	PWM_Motor[0] = MotorSpeed_SP[0];
	PWM_Motor[1] = MotorSpeed_SP[1];*/

	if(LT_Menu == RUNING)
	{
		Motor_EN(1);

		Motor_SpeedSP[0] = MotorSpeed_SP[0];
		Motor_SpeedSP[1] = MotorSpeed_SP[1];
	}
	else
	{
		Motor_SpeedSP[0] = 0;
		Motor_SpeedSP[1] = 0;
		Motor_EN(0);
	}

	MotorRoutine();


}



void LineSensor_Calculation(void)
{
	float temp_err = 0;
	for(int i=0;i<16;i++)
	{
		if(Line_Bit[i] == 1)
			temp_err += Line_Constant[i];
	}

	Line_Eror = temp_err;

}


void M_LT_LineRun(int speed, int pos_sens)
{
	float out_pid;

	float error;

	error = pos_sens - Line_Eror;

	sum_error += error;

	if(sum_error > speed)
		sum_error = speed;
	else if(sum_error < -speed)
		sum_error = -speed;

	Proportional = Kp * 0.1 * Line_Eror;
	Integral = Ki * 0.1  * sum_error;
	Derivative = Kd * 0.1 * (Line_Eror - prev_error);

	out_pid = Proportional + Integral + Derivative;

	if(out_pid > speed)
		out_pid = speed;
	else if(out_pid < -speed)
		out_pid = -speed;

	prev_error = error;

	MotorSpeed_SP[0] = speed + out_pid;
	MotorSpeed_SP[1] = speed - out_pid;


}

void line_view(void)
{

/*
	392
	519

	523
*/

	sensMap[0] = map(Line_ADC[0], Line_Threshold[0], Line_Max[0], 0xFFFF, 0);

	if(sensMap[0] < 0)
		sensMap[0] = 0;

	else if(sensMap[0] > 0xFFFF)
		sensMap[0] = 0xFFFF;

	for(int i=0;i<4;i++)
	{
		SSD1306_Buffer[392+i] = sensMap[0] & 0xff;
		SSD1306_Buffer[519+i] = sensMap[0] & 0xff;
	}


	ssd1306_UpdateScreen(&hi2c1);
}


void Save_Param(void)
{

	HAL_ADC_Stop_DMA(&hadc1);

	memcpy(buff_save,&SpeedJalan,2);
	memcpy(buff_save+2,Line_Threshold,32);
	memcpy(buff_save+34,&Kp,4);
	memcpy(buff_save+38,&Kd,4);
	memcpy(buff_save+42,&Ki,4);


	Remove_File("CONFIG.TXT");
	Create_File("CONFIG.TXT");
	Write_File("CONFIG.TXT", buff_save);
	HAL_ADC_Start_DMA(&hadc1, ADC_Buffer, 6);

}

void Load_Param(void)
{
	HAL_ADC_Stop_DMA(&hadc1);

	if(f_open(&fil, "CONFIG.TXT", FA_OPEN_ALWAYS | FA_READ) != FR_OK)
	{
		Error_Handler();
	}

	if(f_read(&fil, buff_save, 64, &br) != FR_OK)
	{
		Error_Handler();
	}

	f_close(&fil);


	memcpy(&SpeedJalan,buff_save,2);
	memcpy(Line_Threshold,buff_save+2,32);
	memcpy(&Kp,buff_save+34,4);
	memcpy(&Kd,buff_save+38,4);
	memcpy(&Ki,buff_save+42,4);

	HAL_ADC_Start_DMA(&hadc1, ADC_Buffer, 6);
}

void Config_Check(void)
{
	if(f_stat("CONFIG.TXT", &fno) == FR_OK)
		any_config = 1;
	else
		any_config = 0;

	if(!any_config)
	{
		Create_File("CONFIG.TXT");
		Save_Param();
	}



}


void mission(void)
{

	switch(idx_mission)
	{
		case 0:


			MotorSpeed_SP[0] = 100;
			MotorSpeed_SP[1] = 100;

			if (++time_mission > 600)
			{
				time_mission = 0;
				idx_mission = 1;
			}

			break;

		case 1:

			M_LT_LineRun(SpeedJalan,0);

			if (++time_mission > 50)
			{
				if (Line_Bit[4] == 1 || Line_Bit[5] == 1)
				{
					idx_mission = 2;
					time_mission =0;
				}

			}


			break;

		case 2:

			MotorSpeed_SP[0] = 500;
			MotorSpeed_SP[1] = 500;

			if (++time_mission > 100)
			{
				time_mission = 0;
				idx_mission = 3;

			}


			break;

		case 3:

			M_LT_LineRun(SpeedJalan,0);

			if (++time_mission > 150)
			{
				if (Line_Bit[4] == 1 && Line_Bit[5] == 1)
				{
					idx_mission = 41;
					time_mission =0;
				}
			}


			break;

		case 41:

			MotorSpeed_SP[0] = MotorSpeed_SP[1] = 500;

			if(++time_mission>100)
			{
				time_mission =0;
				idx_mission = 4;
			}

			break;

		case 4:


			if (++time_mission > 500)
			{
				if (Line_Bit[12] == 1 && Line_Bit[11] == 1)
				{
					idx_mission = 51;
					time_mission =0;
				}

				M_LT_LineRun(300,0);
			}
			else
			{

				M_LT_LineRun(SpeedJalan,0);

			}

			break;

		case 51:

			MotorSpeed_SP[0] = 500;
			MotorSpeed_SP[1] = 10;

			if(distL > 1020)
			{
				idx_mission = 8;
			}


			break;

		case 5:

			M_LT_LineRun(300,0);
			if (++time_mission > 25)
			{
				if (Line_Bit[10] == 1 && Line_Bit[9] == 1)
				{
					idx_mission = 6;
					time_mission =0;
				}
			}


			break;

		case 6:

			MotorSpeed_SP[0] = 500;
			MotorSpeed_SP[1] = 10;

			if(++time_mission>1000)
			{
				time_mission = 0;
				idx_mission = 255;
			}

			if(time_mission > 40)
			{
				if(
				   Line_Bit[7] == 1 && Line_Bit[8] == 1 &&
				   Line_Bit[0] == 0 && Line_Bit[1] == 0 &&
				   Line_Bit[15] == 0 && Line_Bit[14] == 0
				  )
				{
					time_mission = 0;
					idx_mission = 7;
				}
			}


			break;

		case 7:

			MotorSpeed_SP[0] = 500;
			MotorSpeed_SP[1] = 10;


			if(++time_mission > 20)
			{
				if(
				   Line_Bit[7] == 1 && Line_Bit[8] == 1 &&
				   Line_Bit[0] == 0 && Line_Bit[1] == 0 &&
				   Line_Bit[15] == 0 && Line_Bit[14] == 0
				  )
				{
					time_mission = 0;
					idx_mission = 81;
				}
			}

			break;

		case 81:

			MotorSpeed_SP[0] = 300;
			MotorSpeed_SP[1] = 250;

			if(++time_mission>50)
			{
				time_mission = 0;
				idx_mission = 8;

			}


			break;

		case 8:

			M_LT_LineRun(SpeedJalan,0);

			prev_gyro = yaw_deg;

			if(++time_mission>1000)
			{
				if(Line_Bit[11] == 1 || Line_Bit[12] == 1)
				{
					time_mission = 0;
					idx_mission = 9;
					distL = 0;
					distR = 0;
				}
			}



			break;

		case 9:

			MotorSpeed_SP[0] = 500;
			MotorSpeed_SP[1] = -100;

			if(distL > 180)
			{
				idx_mission = 10;
				distL = 0;
				distR = 0;
			}


			break;

		case 10:

			M_LT_LineRun(SpeedJalan,0);

			if(distR > 120)
			{
				if(Line_Bit[3] == 1 || Line_Bit[4] == 1)
				{
					time_mission = 0;
					idx_mission = 11;
					distL = 0;
					distR = 0;
				}
			}

			break;

		case 11:

			MotorSpeed_SP[1] = 500;
			MotorSpeed_SP[0] = -220;

			if(distR > 150)
			{
				idx_mission = 12;
				distL = 0;
				distR = 0;
			}


			break;

		case 12:


			M_LT_LineRun(SpeedJalan,0);

			if(distR > 220)
			{
				if(Line_Bit[10] == 1 && Line_Bit[11] == 1)
				{
					time_mission = 0;
					idx_mission = 255;
				}
			}

			break;

		case 255:

			M_LT_LineRun(0,0);
			distL = 0;
			distR = 0;

			break;
	}

}


