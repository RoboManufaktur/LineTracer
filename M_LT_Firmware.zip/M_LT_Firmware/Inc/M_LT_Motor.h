/*
 * M_LT_Motor.h
 *
 *  Created on: Mar 18, 2024
 *      Author: ismarintan
 */

#ifndef M_LT_MOTOR_H_
#define M_LT_MOTOR_H_

#include "main.h"
#include "stm32f4xx.h"

#define Motor_EN(x)	HAL_GPIO_WritePin(MOTOR_EN_GPIO_Port, MOTOR_EN_Pin, x)


extern short int ENC_Speed[2];
extern int32_t ENC_Count[2];
extern int16_t PWM_Motor[2];
extern int Motor_SpeedSP[2];

extern float distL, distR;


void Motor_Init(void);
void MotorPWM(int16_t PWM1,int16_t PWM2);
void MotorRoutine(void);
void MotorSetSpeed(int speedL,int speedR);


#endif /* M_LT_MOTOR_H_ */
