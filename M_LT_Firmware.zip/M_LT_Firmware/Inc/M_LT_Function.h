/*
 * M_LT_Function.h
 *
 *  Created on: Mar 18, 2024
 *      Author: ismarintan
 */

#ifndef M_LT_FUNCTION_H_
#define M_LT_FUNCTION_H_

#include "main.h"
#include "stm32f4xx.h"
#include "stdbool.h"
extern int SpeedJalan;

#define LED_PWM(x)	TIM2->CCR1=x
#define BUZZ_PWM(x)	TIM12->CCR1=x
#define PB_ON(x)	HAL_GPIO_WritePin(SW_ON_GPIO_Port,SW_ON_Pin,x)






typedef struct{

	bool BT_L_UP;
	bool BT_L_DOWN;
	bool BT_L_OK;

	bool BT_R_UP;
	bool BT_R_DOWN;
	bool BT_R_OK;

	bool BT_POWER;

	bool BT_L_UP_PREV;
	bool BT_L_DOWN_PREV;
	bool BT_L_OK_PREV;

	bool BT_R_UP_PREV;
	bool BT_R_DOWN_PREV;
	bool BT_R_OK_PREV;

	bool BT_POWER_PREV;




}M_LT_Button_Structure;


typedef enum{

	HOME = 0,
	SETTING = 1,
	RUNING = 2,
	POWER_OFF = 3,
	OFF = 4,
	CALIB = 5,
	SPEED = 6,
	PID = 7


}M_LT_Menu;

extern M_LT_Menu LT_Menu;
extern M_LT_Button_Structure LT_Button;

extern uint8_t test_save,test_read;
extern uint32_t ADC_Buffer[3];

void M_LT_System_Init(void);
void M_LT_ButtonRead(void);
void ADC_Parse(void);
void LineSensor_Read(void);
void LineSensor_Calibration(void);
void LCD_Menu(M_LT_Menu menu);
void M_LT_ControlRoutine(void);
void LineSensor_Calculation(void);
void M_LT_LineRun(int speed, int pos_sens);
void line_view(void);
void Save_Param(void);
void Load_Param(void);
void Config_Check(void);
void mission(void);

#endif /* M_LT_FUNCTION_H_ */
